# Rifzz Generate API

API generator untuk data dummy/testing. API ini tidak membuat atau mendaftarkan akun game nyata.

## Endpoint

GET:
`/api/generate?count=5`

POST:
`/api/generate`

Body JSON:
```json
{
  "count": 5
}
```

Batas count: 1-100.

## Deploy ke Vercel

1. Upload folder ini ke GitHub sebagai repository baru.
2. Di Vercel pilih Import Project.
3. Pilih repository tersebut.
4. Framework Preset: Other.
5. Build Command: kosongkan.
6. Output Directory: kosongkan.
7. Install Command: `npm install`
8. Klik Deploy.

Setelah online:
`https://NAMA-PROJECT.vercel.app/api/generate?count=5`
